# 今天你是什么奶茶？

使用原生 HTML、CSS、JavaScript 和提供的 `milk_tea_assets` 制作的中文竖屏小游戏。没有运行时依赖、后端、网络接口或构建步骤。

## 直接打开，无需安装

1. 将下载的 ZIP **完整解压**到任意文件夹。
2. 双击 `index.html`，用 Chrome、Edge、Safari 或 Firefox 打开。
3. 点击「开始测试」即可游玩。无需 Python、Node.js、安装依赖或启动服务器，也不需要联网。

`index.html` 是自包含的交付版本，已内嵌脚本、样式和全部游戏所需图片，包括液体遮罩。单独复制该文件也能游玩。不要在压缩包预览器里运行 HTML；先解压。

此前的 `localhost:8000` 是本机服务地址，不是公网预览入口。在你电脑没有启动服务时会显示拒绝连接；现在无需访问该地址。当前云环境未提供可公开访问的预览入口。

## 玩法

5 道人格题 → 查看专属结果 → 倒茶 → 加奶 → 加珍珠 → 累计长按 2 秒摇匀 → 插入吸管 → 累计长按 3 秒喝完 → 再测一次。

支持鼠标、触摸，以及聚焦按钮后按住空格或回车。松开、移出、触摸取消或切换窗口时暂停长按；已完成进度保留。刷新从首页重新开始，无需保存个人信息。

计分使用题目规定的映射，平分优先级为：芋泥、抹茶、草莓、焦糖。

## 文件

- `index.html`：自包含离线入口，双击即可游玩。
- `style.css`：响应式布局与动画。
- `game.js`：题目、确定性计分、制作和长按状态管理。
- `milk_tea_assets/`：原始美术素材及其说明。
- `tests/smoke.cjs`：真实 Chromium 端到端测试。
- `scripts/build-standalone.py`：开发者重新打包入口的脚本，玩家不需要运行。

## 测试

无需测试依赖即可游玩。自动测试需要 Node.js 和 Playwright；若本机没有 Playwright，可在项目外安装以保持应用零依赖：

```sh
npm install --prefix /tmp/milk-tea-test playwright
PLAYWRIGHT_BROWSERS_PATH=/tmp/milk-tea-browsers /tmp/milk-tea-test/node_modules/.bin/playwright install chromium
NODE_PATH=/tmp/milk-tea-test/node_modules PLAYWRIGHT_BROWSERS_PATH=/tmp/milk-tea-browsers node tests/smoke.cjs
```

默认测试 HTTP 服务（开发者可选择运行 `python3 -m http.server 8000`），也可通过 `GAME_URL` 指定测试地址。离线入口测试使用 `STANDALONE_HTML=index.html`，不需要服务器。测试涵盖四种人格及平分规则、制作动画、长按暂停/继续/移出/触摸取消、吸管、喝完、重置、刷新、多尺寸布局与资源加载。截图写入 `/tmp/milk-home.png` 和 `/tmp/milk-making.png`。

开发环境使用现有 `/workspace/milk-tea-game` 检出。修改 `game.js` 或 `style.css` 后，开发者运行 `python3 scripts/build-standalone.py` 更新交付入口。玩家直接打开已经生成的 HTML 即可。

此云环境已提供 Playwright 和系统 Chromium，可直接运行：

```sh
STANDALONE_HTML=index.html CHROMIUM_PATH=/usr/bin/chromium node tests/smoke.cjs
```

测试限制：此云环境的受管理 Chromium 禁止导航到 `file://`。离线测试在禁用网络后将原样 HTML 注入浏览器，拒绝任何额外资源请求，再实际运行完整流程；未修改浏览器安全策略，也未宣称已在此环境完成双击文件测试。
