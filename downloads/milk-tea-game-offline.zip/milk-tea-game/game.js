'use strict';
(() => {
  const root = document.querySelector('#game');
  const base = 'milk_tea_assets/';
  const asset = path => window.MILK_TEA_ASSETS?.[path] || base + path;
  const drinks = {
    caramel: { name: '焦糖珍珠奶茶', type: '温柔治愈型', description: '你像一杯温暖的焦糖奶茶，细腻又可靠，总能给平凡的日子增添一点甜。', file: 'caramel_pearl', tea: '#ba8147', milk: '#ddbb87', final: '#cba16e' },
    strawberry: { name: '草莓奶茶', type: '甜蜜元气型', description: '你像一颗新鲜草莓，心里装着许多小快乐，总能为生活增添明亮的色彩。', file: 'strawberry', tea: '#c9757d', milk: '#ecc0bd', final: '#dda2a6' },
    matcha: { name: '抹茶奶茶', type: '清新自在型', description: '你有自己的生活节奏，喜欢安静地感受世界，也懂得享受独处的时光。', file: 'matcha', tea: '#81944e', milk: '#c1d09c', final: '#a5b97c' },
    taro: { name: '芋泥奶茶', type: '浪漫幻想型', description: '你的世界充满奇妙想象，喜欢发现生活中那些不经意的小美好。', file: 'taro', tea: '#9180af', milk: '#cbbce0', final: '#b09cc9' }
  };
  const questions = [
    ['难得拥有一个自由的下午，你会？', ['在家休息，享受独处', '约朋友一起出去玩', '去陌生的地方随便逛逛']],
    ['你喜欢什么样的天气？', ['温暖舒适的晴天', '明亮灿烂的好天气', '安静朦胧的雨天']],
    ['朋友通常怎样形容你？', ['温柔可靠', '活泼开朗', '安静细腻']],
    ['你喜欢什么生活节奏？', ['稳定舒适', '热闹充实', '自由随性']],
    ['你最想收到哪种礼物？', ['贴心的小礼物', '有趣的新奇玩具', '一本书或一件艺术品']]
  ];
  const mapping = ['taro', 'matcha', 'matcha', 'taro', 'taro'];
  const priority = ['taro', 'matcha', 'strawberry', 'caramel'];
  let scores, question, result, step, busy, shakeTime, drinkTime, holdCleanup;
  let timers = new Set();
  function later(fn, ms) { const id = setTimeout(() => { timers.delete(id); fn(); }, ms); timers.add(id); }
  const img = (path, cls = '', alt = '') => `<img class="${cls}" src="${asset(path)}" alt="${alt}" draggable="false">`;
  const brand = '<div class="brand">一杯小小的快乐</div>';
  const button = text => `<button class="primary" id="action" type="button">${text}</button>`;
  function screen(content, name) {
    if (holdCleanup) { holdCleanup(); holdCleanup = null; }
    for (const id of timers) clearTimeout(id);
    timers.clear(); busy = false;
    root.dataset.screen = name;
    root.innerHTML = `<section class="screen">${brand}${content}</section>`;
  }
  function action(fn) { document.querySelector('#action').onclick = fn; }
  function reset() {
    scores = { caramel: 0, strawberry: 0, matcha: 0, taro: 0 };
    question = 0; result = null; step = 0; shakeTime = 0; drinkTime = 0;
    home();
  }
  function home() {
    screen(`<header class="hero-head"><p class="eyebrow">TODAY’S MILK TEA</p><h1>今天你是<br>什么<em>奶茶</em>？</h1><p class="subtitle">测测你的奶茶体质，<br>制作一杯专属奶茶！</p></header><div class="hero">${img('drinks/result_caramel_pearl.png', 'hero-drink', '温柔的焦糖珍珠奶茶')}${decor()}<span class="hero-note">把日子调成喜欢的甜度</span></div><footer class="footer">${button('开始测试　→')}<p class="fine">5 道小问题 · 遇见今天的自己</p></footer>`, 'home');
    action(quiz);
  }
  function decor() { return img('decor/flower.png', 'deco flower') + img('decor/star.png', 'deco star') + img('decor/bow.png', 'deco bow'); }
  function quiz() {
    const q = questions[question];
    screen(`<div class="quiz-top"><span>寻找你的奶茶体质</span><span>${question + 1} / 5</span></div><div class="dots" aria-label="第 ${question + 1} 题，共 5 题">${questions.map((_, i) => `<span class="${i <= question ? 'filled' : ''}"></span>`).join('')}</div><div class="question-area">${img('decor/flower.png', 'question-deco')}<p class="eyebrow">QUESTION 0${question + 1}</p><h2>${q[0]}</h2><div class="answers">${q[1].map((a, i) => `<button type="button" class="answer" data-choice="${i}"><span class="letter">${'ABC'[i]}</span><span>${a}</span></button>`).join('')}</div></div><p class="fine">没有标准答案，跟着心意选就好</p>`, 'quiz');
    root.querySelectorAll('.answer').forEach(b => b.onclick = () => {
      if (busy) return;
      busy = true;
      root.querySelectorAll('.answer').forEach(el => el.disabled = true);
      scores[Number(b.dataset.choice) === 0 ? 'caramel' : Number(b.dataset.choice) === 1 ? 'strawberry' : mapping[question]]++;
      later(() => {
        question++;
        if (question < 5) quiz();
        else { result = priority.reduce((best, key) => scores[key] > scores[best] ? key : best, priority[0]); showResult(); }
      }, 200);
    });
  }
  function showResult() {
    const d = drinks[result];
    screen(`<header class="result-head"><p class="eyebrow">你的专属奶茶已送达</p><h2>${d.name}</h2><span class="pill">${d.type}</span></header><div class="result-hero">${img(`drinks/result_${d.file}.png`, '', d.name)}</div><p class="description">${d.description}</p><footer class="footer">${button('制作我的奶茶　→')}<p class="fine">加一点心意，调一杯自己</p></footer>`, 'result');
    root.dataset.result = result;
    action(() => { step = 0; make(); });
  }
  function cup(full = false, straw = false) {
    const positions = [[28,10],[39,9],[50,11],[61,10],[33,16],[44,17],[55,18],[62,16]];
    return `<div class="cup" role="img" aria-label="${full ? '制作好的奶茶' : '透明奶茶杯'}">${img('cup/cup_back.png', 'cup-layer')}<div class="inside"><div class="liquid" style="height:${full ? 57.5 : 0}%;--liquid:${result ? drinks[result].final : '#cba16e'}"><div class="milk-swirl"></div></div>${positions.map(([x,y],i)=>`<img src="${asset('tools/pearl.png')}" alt="" class="pearl ${full ? 'settled' : ''}" style="--x:${x}%;--y:${y}%;--delay:${i * 45}ms" draggable="false">`).join('')}</div>${img('tools/straw.png', `straw ${straw ? 'inserted' : ''}`)}${img('cup/cup_front.png', 'cup-layer')}</div>`;
  }
  function make() {
    screen(`<header class="make-head"><p class="eyebrow">专属调饮时间</p><h2>${drinks[result].name}</h2><p class="subtitle" id="instruction" aria-live="polite">先为快乐，倒一点茶底</p><div class="steps">${[1,2,3,4].map(n=>`<span>${n}</span>`).join('')}</div></header><div class="workbench">${cup()}<div class="stream"></div><img class="tool" alt="制作工具" hidden></div><footer class="footer"><p class="hint" id="hint">轻点按钮，开始制作</p><div class="meter" hidden><span></span></div>${button('倒入茶底')}<p class="fine">一点点甜，刚刚好</p></footer>`, 'make');
    nextStep();
  }
  function nextStep() {
    const labels = ['倒入茶底', '加入牛奶', '加入珍珠', '长按摇晃', '开始享用'];
    const tips = ['先为快乐，倒一点茶底', '加一点奶香，让心情柔软下来', '圆滚滚的珍珠，是快乐的小惊喜', '摇一摇，让甜蜜慢慢融合', '你的专属奶茶做好啦！'];
    const b = root.querySelector('#action');
    b.disabled = false; b.textContent = labels[step];
    root.querySelector('#instruction').textContent = tips[step];
    root.querySelectorAll('.steps span').forEach((el,i) => el.classList.toggle('active', i <= step));
    if (step === 3) {
      root.querySelector('.meter').hidden = false;
      root.querySelector('#hint').textContent = '按住约 2 秒 · 松开可暂停';
      b.onclick = null;
      bindHold(2000, () => shakeTime, v => {
        shakeTime = v;
        root.querySelector('.milk-swirl').style.opacity = .8 * (1 - v / 2000);
        root.querySelector('.liquid').style.setProperty('--liquid', blend(drinks[result].milk, drinks[result].final, v/2000));
      }, () => { step++; nextStep(); }, active => root.querySelector('.cup').classList.toggle('shaking', active));
    } else if (step === 4) {
      if (holdCleanup) { holdCleanup(); holdCleanup = null; }
      root.querySelector('#hint').textContent = '这一杯，为今天的你而做';
      // Replace the hold target so its eventual pointer-up cannot click the next action.
      const enjoy = b.cloneNode(true);
      b.replaceWith(enjoy);
      enjoy.classList.remove('hold-button');
      enjoy.removeAttribute('aria-pressed');
      enjoy.onclick = drink;
    } else b.onclick = pour;
  }
  function blend(a,b,t) {
    const parts = [1,3,5].map(i => Math.round(parseInt(a.slice(i,i+2),16)*(1-t)+parseInt(b.slice(i,i+2),16)*t));
    return `rgb(${parts.join(',')})`;
  }
  function pour() {
    if (busy) return;
    busy = true;
    const b = root.querySelector('#action'), tool = root.querySelector('.tool'), liquid = root.querySelector('.liquid'), stream = root.querySelector('.stream');
    b.disabled = true; b.textContent = ['茶香慢慢升起…','奶香正在融合…','快乐落进杯子里…'][step];
    tool.src = asset(`tools/${['tea_pitcher','milk_pitcher','pearl_bowl'][step]}.png`);
    tool.hidden = false; tool.className = `tool pouring ${step === 2 ? 'bowl' : ''}`;
    if (step < 2) {
      stream.style.setProperty('--stream', step === 0 ? drinks[result].tea : '#fff8ed');
      stream.classList.add('flowing');
      liquid.style.setProperty('--liquid', step === 0 ? drinks[result].tea : drinks[result].milk);
      liquid.style.height = step === 0 ? '30.6%' : '57.5%';
      if (step === 1) root.querySelector('.cup').classList.add('milk-added');
    } else root.querySelectorAll('.pearl').forEach(el=>el.classList.add('fall'));
    later(() => {
      tool.hidden = true; tool.className = 'tool'; stream.classList.remove('flowing');
      if (step === 2) root.querySelectorAll('.pearl').forEach(el => { el.classList.remove('fall'); el.classList.add('settled'); });
      busy = false; step++; nextStep();
    }, step === 2 ? 1150 : 1500);
  }
  function drink() {
    screen(`<header class="make-head"><p class="eyebrow">把快乐喝进心里</p><h2>现在，是享用时间</h2><p class="subtitle" id="instruction" aria-live="polite">插入吸管，尝尝你的专属味道</p></header><div class="workbench drinking">${cup(true)}</div><footer class="footer"><p class="hint" id="hint">慢慢喝，今天的甜属于你</p><div class="meter" hidden><span></span></div>${button('插入吸管')}<p class="fine">${drinks[result].name} · ${drinks[result].type}</p></footer>`, 'drink');
    action(() => {
      if (busy) return; busy = true;
      const b = root.querySelector('#action'); b.disabled = true; b.textContent = '吸管就位中…';
      root.querySelector('.straw').classList.add('inserted');
      later(() => {
        busy = false; b.disabled = false; b.onclick = null; b.textContent = '长按喝奶茶';
        root.querySelector('#instruction').textContent = '咕噜咕噜，每一口都是小快乐';
        root.querySelector('#hint').textContent = '按住约 3 秒 · 松开可暂停';
        root.querySelector('.meter').hidden = false;
        bindHold(3000, () => drinkTime, v => {
          drinkTime = v;
          root.querySelector('.liquid').style.height = `${57.5 * (1-v/3000)}%`;
          root.querySelectorAll('.pearl').forEach((el,i) => el.style.opacity = v/3000 > (i+1)/9 ? '0' : '1');
        }, end);
      }, 850);
    });
  }
  function bindHold(duration, get, set, done, active = () => {}) {
    const b = root.querySelector('#action'); b.classList.add('hold-button');
    let holding = false, frame = 0, last = 0, pointer = null;
    const stop = () => { holding = false; cancelAnimationFrame(frame); active(false); b.setAttribute('aria-pressed','false'); pointer = null; };
    const tick = now => {
      if (!holding) return;
      const value = Math.min(duration, get() + Math.min(now - last, 80)); last = now;
      set(value); root.querySelector('.meter span').style.width = `${value/duration*100}%`;
      if (value >= duration) { stop(); done(); return; }
      frame = requestAnimationFrame(tick);
    };
    const start = () => { if (holding || b.disabled) return; holding = true; last = performance.now(); active(true); b.setAttribute('aria-pressed','true'); frame = requestAnimationFrame(tick); };
    const down = e => { if (!e.isPrimary || (e.pointerType === 'mouse' && e.button !== 0)) return; e.preventDefault(); pointer = e.pointerId; start(); };
    const move = e => { if (!holding || e.pointerId !== pointer) return; const r=b.getBoundingClientRect(); if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom) stop(); };
    const up = e => { if (e.pointerId === pointer) stop(); };
    const keyDown = e => { if(e.code==='Space'||e.code==='Enter'){e.preventDefault();start();} };
    const keyUp = e => { if(e.code==='Space'||e.code==='Enter'){e.preventDefault();stop();} };
    const visibility = () => { if(document.hidden) stop(); };
    const context = e => e.preventDefault();
    const listeners = [[b,'pointerdown',down],[b,'pointerleave',stop],[b,'lostpointercapture',stop],[window,'pointermove',move],[window,'pointerup',up],[window,'pointercancel',stop],[window,'blur',stop],[b,'blur',stop],[b,'keydown',keyDown],[b,'keyup',keyUp],[b,'contextmenu',context],[document,'visibilitychange',visibility]];
    for (const [el,event,fn] of listeners) el.addEventListener(event,fn);
    holdCleanup = () => { stop(); for(const [el,event,fn] of listeners) el.removeEventListener(event,fn); };
  }
  function end() {
    screen(`<header class="end-head"><p class="eyebrow">TODAY’S LITTLE HAPPINESS</p><h2>咕噜咕噜，<br>今日份快乐已喝完！</h2><p class="subtitle">你今天喝掉了一杯<br><strong>${drinks[result].name}</strong>。</p></header><div class="end-hero">${cup(false,true)}${decor()}</div><p class="end-message">愿你的每一天，<br>都有刚刚好的甜。</p><footer class="footer">${button('再测一次')}<p class="fine">下一杯快乐，随时为你准备</p></footer>`, 'end');
    action(() => { delete root.dataset.result; reset(); });
  }
  reset();
})();
