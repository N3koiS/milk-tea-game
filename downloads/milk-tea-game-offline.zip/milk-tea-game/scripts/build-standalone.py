"""Developer-only packaging; players simply double-click the generated index.html."""
from pathlib import Path
import base64
import json
import re

root = Path(__file__).resolve().parents[1]
assets = root / 'milk_tea_assets'
def data_uri(path):
    mime = 'image/svg+xml' if path.suffix == '.svg' else 'image/png'
    return f'data:{mime};base64,' + base64.b64encode(path.read_bytes()).decode('ascii')

paths = [
    'cup/cup_back.png', 'cup/cup_front.png',
    'tools/tea_pitcher.png', 'tools/milk_pitcher.png', 'tools/pearl_bowl.png',
    'tools/pearl.png', 'tools/straw.png',
    'drinks/result_caramel_pearl.png', 'drinks/result_strawberry.png',
    'drinks/result_matcha.png', 'drinks/result_taro.png',
    'decor/flower.png', 'decor/star.png', 'decor/bow.png',
]
images = {p: data_uri(assets / p) for p in paths}
css = (root / 'style.css').read_text()
css = re.sub(r"url\('milk_tea_assets/([^']+)'\)", lambda m: f'url("{data_uri(assets / m[1])}")', css)
js = (root / 'game.js').read_text()
assert '</script' not in js.lower()
html = '''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#f8eddd">
<meta name="description" content="测测你的奶茶体质，亲手制作一杯专属奶茶。离线双击即可游玩。">
<title>今天你是什么奶茶？</title>
<!-- Self-contained release. Regenerate with scripts/build-standalone.py after source changes. -->
'''
html += '<link rel="icon" href="' + data_uri(assets / 'decor/flower.svg') + '">\n'
html += '<style>\n' + css + '\n</style>\n</head>\n'
html += '<body><main id="game" aria-label="今天你是什么奶茶？"></main>\n<script>\n'
html += 'window.MILK_TEA_ASSETS=' + json.dumps(images, ensure_ascii=False) + ';\n'
html += js + '\n</script>\n</body>\n</html>\n'
(root / 'index.html').write_text(html)
print(f'Self-contained index.html: {len(html.encode()):,} bytes')
