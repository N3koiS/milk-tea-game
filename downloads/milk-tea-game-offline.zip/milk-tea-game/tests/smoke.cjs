// Run against the static server: node tests/smoke.cjs
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
(async () => {
  const browser = await chromium.launch({headless:true, ...(process.env.CHROMIUM_PATH ? {executablePath:process.env.CHROMIUM_PATH} : {})});
  const page = await browser.newPage({viewport:{width:390,height:844},hasTouch:true,isMobile:true});
  const errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  page.on('response',r=>{if(r.status()>=400)errors.push(`${r.status()} ${r.url()}`)});
  const standalone = process.env.STANDALONE_HTML;
  const url=standalone ? 'http://milk-tea-offline.test/' : process.env.GAME_URL || 'http://127.0.0.1:8000';
  if (standalone) {
    // The managed browser prohibits file://. Supply the unchanged release document
    // in memory with networking offline. Any dependent request must fail this test.
    const html=fs.readFileSync(path.resolve(standalone),'utf8');
    await page.context().setOffline(true);
    await page.route('**/*', route => {
      if(route.request().isNavigationRequest() && route.request().url()===url)
        return route.fulfill({status:200,contentType:'text/html; charset=utf-8',body:html});
      errors.push('Unexpected dependency: '+route.request().url());
      return route.abort();
    });
    page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
    page.on('requestfailed',r=>errors.push('Failed resource: '+r.url()));
  }
  const expectScreen = name => page.waitForSelector(`#game[data-screen="${name}"]`);
  const action = () => page.locator('#action');
  async function choose(answers, expected) {
    await page.goto(url); await action().click();
    for(let i=0;i<answers.length;i++) {
      await page.locator('.quiz-top').filter({hasText:`${i+1} / 5`}).waitFor();
      await page.locator(`[data-choice="${answers[i]}"]`).click();
    }
    await expectScreen('result');
    assert.equal(await page.locator('#game').getAttribute('data-result'),expected);
    console.log(`PASS personality: ${expected}, answers ${answers.join('')}`);
  }
  async function bounds() {
    const bad = await page.evaluate(()=> {
      const game=document.querySelector('#game').getBoundingClientRect();
      return [...document.querySelectorAll('h1,h2,.subtitle,.description,.answer,#action,.fine,.hint,.end-message')].filter(el=> {
        const r=el.getBoundingClientRect();return r.top < game.top-1 || r.bottom > game.bottom+1 || r.left < game.left-1 || r.right > game.right+1;
      }).map(e=>e.textContent);
    });
    assert.deepEqual(bad,[],'visible text / buttons must stay in game bounds');
  }
  async function hold(ms) {
    const r=await action().boundingBox(); await page.mouse.move(r.x+r.width/2,r.y+r.height/2); await page.mouse.down(); await page.waitForTimeout(ms); await page.mouse.up();
  }
  const meter = () => page.locator('.meter span').evaluate(el=>parseFloat(el.style.width)||0);
  await choose([0,0,0,0,0],'caramel');
  await choose([1,1,1,1,1],'strawberry');
  await choose([0,2,2,1,2],'matcha');
  await choose([2,2,2,2,0],'taro'); // taro/matcha tie: taro wins
  await choose([0,0,1,1,2],'strawberry'); // strawberry/caramel tie
  await choose([0,2,2,0,1],'matcha'); // matcha/caramel tie
  await bounds();
  await action().click(); await expectScreen('make'); await bounds();
  for(const [label,next,height] of [['倒入茶底','加入牛奶',30.6],['加入牛奶','加入珍珠',57.5],['加入珍珠','长按摇晃',57.5]]) {
    await action().click();
    assert.equal(await action().isDisabled(),true);
    await page.locator('.tool').waitFor({state:'visible',timeout:1000});
    await page.getByRole('button',{name:next,exact:true}).waitFor();
    assert.deepEqual(await page.locator('img[src]').evaluateAll(els=>els.filter(e=>!e.complete||!e.naturalWidth).map(e=>e.className)),[]);
    if (standalone) assert(await page.locator('.inside').evaluate(el=>getComputedStyle(el).maskImage.includes('data:image/png;base64,')));
    assert.equal(await page.locator('.liquid').evaluate(el=>parseFloat(el.style.height)),height);
    console.log(`PASS ${label}`);
  }
  assert.equal(await page.locator('.pearl.settled').count(),8);
  await hold(600); const partial=await meter(); assert(partial>10&&partial<70);
  await page.waitForTimeout(250); assert.equal(await meter(),partial);
  const b=await action().boundingBox(); await page.mouse.move(b.x+20,b.y+20); await page.mouse.down(); await page.waitForTimeout(150); await page.mouse.move(0,0); const left=await meter(); await page.waitForTimeout(200); assert.equal(await meter(),left); await page.mouse.up();
  // Touch cancellation must also pause; use native Chromium touch dispatch.
  const client=await page.context().newCDPSession(page);
  await client.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:b.x+25,y:b.y+20}]}); await page.waitForTimeout(150);
  await client.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]}); const cancelled=await meter(); await page.waitForTimeout(150); assert.equal(await meter(),cancelled);
  await page.screenshot({path:'/tmp/milk-making.png'});
  await hold(2300); await page.getByRole('button',{name:'开始享用',exact:true}).waitFor(); console.log('PASS shake: pause, leave, touch cancellation, resume');
  await action().click(); await expectScreen('drink'); await action().click();
  await page.getByRole('button',{name:'长按喝奶茶',exact:true}).waitFor();
  assert.equal(await page.locator('.straw').evaluate(el=>getComputedStyle(el).opacity),'1');
  await hold(650); const remaining=await page.locator('.liquid').evaluate(el=>parseFloat(el.style.height)); assert(remaining>0&&remaining<57.5);
  await page.waitForTimeout(200); assert.equal(await page.locator('.liquid').evaluate(el=>parseFloat(el.style.height)),remaining);
  await hold(3200); await expectScreen('end'); await bounds(); console.log('PASS straw, drinking pause/resume, end');
  await action().click(); await expectScreen('home');
  await action().click(); await page.locator('[data-choice="0"]').click(); await page.reload(); await expectScreen('home');
  console.log('PASS restart and refresh');
  for(const size of [{width:320,height:568},{width:375,height:667},{width:390,height:844},{width:430,height:932},{width:1440,height:900}]) {
    await page.setViewportSize(size);await page.goto(url);await bounds();
    assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
    await action().click();await bounds();
    for(let i=0;i<5;i++) {await page.locator('.quiz-top').filter({hasText:`${i+1} / 5`}).waitFor();await page.locator('[data-choice="0"]').click();}
    await expectScreen('result'); await bounds();
    await action().click();await bounds();console.log(`PASS layout ${size.width}x${size.height}`);
  }
  await page.setViewportSize({width:390,height:844});await page.goto(url);await page.screenshot({path:'/tmp/milk-home.png'});
  assert.deepEqual(await page.locator('img').evaluateAll(els=>els.filter(e=>!e.complete||e.naturalWidth===0).map(e=>e.src)),[]);
  assert.deepEqual(errors,[]);
  await browser.close();console.log('All smoke checks passed. No browser errors or failed requests.');
})().catch(e=>{console.error(e);process.exit(1)});
